/*
 * Service worker: watches network requests per tab and keeps only the ones
 * that belong to a known analytics / advertising tool.
 *
 * Service workers are suspended when idle, so state lives in an in-memory map
 * that is mirrored (debounced) to chrome.storage.session.
 */
importScripts('lib/signatures.js', 'lib/core.js');

const Core = self.AuditorCore;
const MAX_STORED = 600;
const PERSIST_DELAY_MS = 500;

const mem = new Map();   // tabId -> record
const dirty = new Set();
let persistTimer = null;
let queue = Promise.resolve();

const storeKey = (tabId) => `tab:${tabId}`;
const enqueue = (fn) => { queue = queue.then(fn).catch((e) => console.error('[auditor]', e)); };

function freshRecord(url, partial) {
  return { url: url || null, startedAt: Date.now(), total: 0, requests: [], toolIds: [], partial: !!partial };
}

function schedulePersist(tabId) {
  dirty.add(tabId);
  if (persistTimer) return;
  persistTimer = setTimeout(async () => {
    persistTimer = null;
    const ids = [...dirty];
    dirty.clear();
    const payload = {};
    for (const id of ids) {
      const rec = mem.get(id);
      if (!rec) continue;
      payload[storeKey(id)] = rec;
      chrome.action.setBadgeText({ tabId: id, text: rec.toolIds.length ? String(rec.toolIds.length) : '' }).catch(() => {});
    }
    try { await chrome.storage.session.set(payload); } catch (e) { console.warn('[auditor] persist failed', e); }
  }, PERSIST_DELAY_MS);
}

/** Run fn(record) now if the tab is in memory, otherwise load/create it first. */
function withRecord(tabId, fn) {
  const cached = mem.get(tabId);
  if (cached) { fn(cached); return; }
  enqueue(async () => {
    if (!mem.has(tabId)) {
      const stored = (await chrome.storage.session.get(storeKey(tabId)))[storeKey(tabId)];
      // No main-frame request seen for this tab: the extension was started after the page loaded.
      mem.set(tabId, stored || freshRecord(null, true));
    }
    fn(mem.get(tabId));
  });
}

chrome.webRequest.onBeforeRequest.addListener(
  (d) => {
    if (d.tabId < 0) return;

    if (d.type === 'main_frame') {
      mem.set(d.tabId, freshRecord(d.url, false));
      chrome.action.setBadgeBackgroundColor({ tabId: d.tabId, color: '#4f46e5' }).catch(() => {});
      chrome.action.setBadgeText({ tabId: d.tabId, text: '' }).catch(() => {});
      schedulePersist(d.tabId);
      return;
    }

    const matches = Core.matchRequest(d.url);
    withRecord(d.tabId, (rec) => {
      rec.total++;
      if (!matches.length) return;
      if (rec.requests.length < MAX_STORED) {
        rec.requests.push({
          url: d.url.slice(0, 1500),
          ts: Math.round(d.timeStamp),
          method: d.method,
          type: d.type
        });
      }
      matches.forEach((m) => { if (!rec.toolIds.includes(m.toolId)) rec.toolIds.push(m.toolId); });
      schedulePersist(d.tabId);
    });
  },
  { urls: ['http://*/*', 'https://*/*'] }
);

chrome.tabs.onRemoved.addListener((tabId) => {
  mem.delete(tabId);
  dirty.delete(tabId);
  chrome.storage.session.remove(storeKey(tabId)).catch(() => {});
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg || msg.type !== 'getRecord') return;
  const tabId = msg.tabId;
  const reply = () => sendResponse(mem.get(tabId) || null);
  if (mem.has(tabId)) { reply(); return; }
  enqueue(async () => {
    if (!mem.has(tabId)) {
      const stored = (await chrome.storage.session.get(storeKey(tabId)))[storeKey(tabId)];
      if (stored) mem.set(tabId, stored);
    }
    reply();
  });
  return true; // async response
});
