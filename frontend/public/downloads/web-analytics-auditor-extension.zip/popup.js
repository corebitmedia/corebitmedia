(function () {
  'use strict';
  var Core = window.AuditorCore, R = window.AuditorRender;
  var app = document.getElementById('app');
  var live = document.getElementById('live');

  var state = { tab: null, pageFacts: null, report: null, activeTab: 'overview', scanning: false, lastUrl: null };

  function getActiveTab() {
    return chrome.tabs.query({ active: true, currentWindow: true }).then(function (t) { return t[0]; });
  }

  function getRecord(tabId) {
    return new Promise(function (resolve) {
      chrome.runtime.sendMessage({ type: 'getRecord', tabId: tabId }, function (rec) {
        void chrome.runtime.lastError;
        resolve(rec || null);
      });
    });
  }

  function isScannable(url) { return /^https?:\/\//i.test(url || ''); }

  function scanPage(tab) {
    return chrome.scripting.executeScript({
      target: { tabId: tab.id }, world: 'MAIN', func: window.AuditorPageScan.collect, args: [Core.allGlobals()]
    }).then(function (res) { return res && res[0] && res[0].result; });
  }

  // ---------------------------------------------------------------- build + render

  function buildReport() {
    var tab = state.tab, rec = state.record, page = state.pageFacts || {};
    var facts = Object.assign({}, page, {
      url: page.url || tab.url,
      requests: rec ? rec.requests : [],
      requestsTotal: rec ? rec.total : 0,
      networkCaptured: true,
      partialCapture: !rec || rec.partial,
      mode: 'runtime',
      notes: []
    });
    if (facts.partialCapture) {
      facts.notes.push('Network capture began after this page loaded, so earlier hits are missing. Use “Reload & audit” for a complete result.');
    }
    return Core.analyze(facts);
  }

  function render() {
    if (!state.tab || !isScannable(state.tab.url)) {
      app.textContent = '';
      app.appendChild(R.h('div', { class: 'empty' },
        R.h('strong', { text: 'This page can’t be audited' }),
        R.h('p', { text: 'Open a normal http(s) page. Browser pages such as chrome:// and the Web Store are off-limits to extensions.' })));
      live.textContent = '';
      return;
    }
    state.report = buildReport();
    var scrollTop = app.scrollTop;
    app.textContent = '';
    app.appendChild(R.renderReport(state.report, {
      tab: state.activeTab,
      onTab: function (t) { state.activeTab = t; }
    }));
    app.scrollTop = scrollTop;
    live.textContent = 'Live · ' + new Date().toLocaleTimeString();
  }

  async function refresh(opts) {
    opts = opts || {};
    try {
      var tab = await getActiveTab();
      if (!tab) return;
      if (state.lastUrl !== tab.url) { opts.scanPage = true; state.activeTab = state.activeTab || 'overview'; }
      state.tab = tab;
      state.lastUrl = tab.url;
      if (!isScannable(tab.url)) { render(); return; }
      state.record = await getRecord(tab.id);
      if (opts.scanPage || !state.pageFacts) {
        try { state.pageFacts = await scanPage(tab); } catch (e) { state.pageFacts = state.pageFacts || {}; }
      }
      render();
    } catch (e) {
      app.textContent = '';
      app.appendChild(R.h('div', { class: 'empty' }, R.h('strong', { text: 'Scan failed' }), R.h('p', { text: String(e && e.message || e) })));
    }
  }

  // ---------------------------------------------------------------- actions

  function download(name, text, type) {
    var url = URL.createObjectURL(new Blob([text], { type: type }));
    var a = document.createElement('a');
    a.href = url; a.download = name; a.click();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }
  function slug() {
    try { return new URL(state.report.url).hostname.replace(/[^a-z0-9.-]/gi, '_'); } catch (e) { return 'page'; }
  }

  document.getElementById('rescan').addEventListener('click', function () { refresh({ scanPage: true }); });
  document.getElementById('reload').addEventListener('click', function () {
    if (!state.tab) return;
    state.pageFacts = null;
    chrome.tabs.reload(state.tab.id, { bypassCache: true });
  });
  document.getElementById('export-json').addEventListener('click', function () {
    if (state.report) download('analytics-audit-' + slug() + '.json', JSON.stringify(state.report, null, 2), 'application/json');
  });
  document.getElementById('export-csv').addEventListener('click', function () {
    if (state.report) download('analytics-audit-' + slug() + '.csv', Core.reportToCsv(state.report), 'text/csv');
  });
  document.getElementById('copy').addEventListener('click', function () {
    if (!state.report) return;
    var r = state.report;
    var lines = ['Analytics audit: ' + r.url, 'Score ' + r.score + '/100 (grade ' + r.grade + ')', ''];
    r.tools.filter(function (t) { return t.status !== 'cookie'; }).forEach(function (t) {
      lines.push('- ' + t.name + ' [' + t.status + ']' + (t.ids.length ? ' ' + t.ids.map(function (i) { return i.id; }).join(', ') : ''));
    });
    lines.push('');
    r.findings.filter(function (f) { return f.severity !== 'pass'; }).forEach(function (f) { lines.push('• [' + f.severity + '] ' + f.title); });
    navigator.clipboard.writeText(lines.join('\n'));
    var b = document.getElementById('copy'); b.textContent = 'Copied'; setTimeout(function () { b.textContent = 'Copy summary'; }, 900);
  });

  // Re-scan the page DOM when the tab finishes loading; refresh network data on a timer.
  chrome.tabs.onUpdated.addListener(function (id, info) {
    if (state.tab && id === state.tab.id && info.status === 'complete') refresh({ scanPage: true });
  });
  setInterval(function () { if (!document.hidden) refresh(); }, 1500);
  refresh({ scanPage: true });
})();
